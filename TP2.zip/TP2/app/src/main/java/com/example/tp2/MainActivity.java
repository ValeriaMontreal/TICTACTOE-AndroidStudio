package com.example.tp2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

//
public class MainActivity extends AppCompatActivity  {
    private Button[] grille = new Button[9];
    private Jeu leJeu;
    private boolean termine;
    private int[] tabGagne;
    private Button reStart;
    private TextView message;
    private String mess;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        grille[0] = findViewById(R.id.button_0);
        grille[1] = findViewById(R.id.button_1);
        grille[2] = findViewById(R.id.button_2);
        grille[3] = findViewById(R.id.button_3);
        grille[4] = findViewById(R.id.button_4);
        grille[5] = findViewById(R.id.button_5);
        grille[6] = findViewById(R.id.button_6);
        grille[7] = findViewById(R.id.button_7);
        grille[8] = findViewById(R.id.button_8);
        reStart = findViewById(R.id.button_reset);
        message = (TextView) findViewById(R.id.messGame);

        leJeu = new Jeu();
        tabGagne = new int[3];
        reStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nouveau();
            }
        });
   }

    @SuppressLint("ResourceAsColor")
    public void nouveau() {
        for( int i = 0; i<grille.length; i++){
            String buttonID = "button_"+i;
            int resourceID = getResources().getIdentifier(buttonID, "id", getPackageName());
            grille[i].setBackgroundResource(android.R.drawable.btn_default);
            grille[i].setText("");
            grille[i] = findViewById(resourceID);
        }
        //aspect initial de l'IU voir exemple AlertDialog
        //place "" comme text de boutons
        leJeu.initialise();
        for(int i=0; i<3; i++)
            tabGagne[i]=-1;
        termine = false;
        message.setText("");

    }

    public int pos(Button c){
        int i = 0;
        while (grille[i]!=c) {
            i++;
        }
        return i;
    }

    public void marquer(int[] posGagnante){
        for(int i=0; i<3; i++){
            grille [posGagnante[i]].setBackgroundColor(Color.BLUE);
            }
    }

    public void choix(View v) {
        Button choix = (Button)v;

        int[]posGagnante = new int[3];
        int i;
        if(termine)
            return;
        if(choix.getText().toString().equals("")){
         choix.setText("X");
         choix.setTextColor(Color.parseColor("#FFC34A"));
            i = pos(choix);
         leJeu.setX(i);
         if(leJeu.gagnant("X", posGagnante)) {
             termine=true;
             marquer(posGagnante);
             mess=getString(R.string.messageX);
             Toast.makeText(MainActivity.this, getString(R.string.messageX), Toast.LENGTH_LONG).show();
             message.setText(mess);
             }
         else
             if(leJeu.isPartieNulle()==false){
                 i=leJeu.getO();
                 grille[i].setText("O");
                 grille[i].setTextColor(Color.parseColor("#3733FF"));
                 if(leJeu.gagnant("O", posGagnante)){
                     termine=true;
                     marquer(posGagnante);
                     mess=getString(R.string.message);
                     Toast.makeText(MainActivity.this, getString(R.string.message), Toast.LENGTH_LONG).show();
                     message.setText(mess);
                 }
             }
             else	
             {
                 termine = true;
                 mess=getString(R.string.drawn);
                 Toast.makeText(MainActivity.this, getString(R.string.drawn), Toast.LENGTH_LONG).show();
                 message.setText(mess);
             }
        }
    }
}